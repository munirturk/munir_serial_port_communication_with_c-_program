﻿namespace KoboldCom
{
    /// <summary>
    /// 数据接收委托
    /// </summary>
    public delegate void DataReceivedHandler(ICommunication comm);
}